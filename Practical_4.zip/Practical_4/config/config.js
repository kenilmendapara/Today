const sessionSecret = "mysitesessionsecret";

const emailUser = "joganinensi1121@gmail.com";
const password = "zaesuiixgeaayupa"

module.exports = {
    sessionSecret,
    emailUser,
    password
};