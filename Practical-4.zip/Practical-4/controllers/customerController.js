const Customer = require('../models/customerModel');

//<<<----- For Get Customer Add Page----->>>
const getAddCustomerPage = async (req, res) => {
    try {

        res.render('addCustomer', { title: "Add New Customer" })

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Insert Customer ----->>>
const postAddCustomerPage = async (req, res) => {

    try {
            const customer = new Customer({
                customername: req.body.customername,
                email: req.body.email,
                mobileno: req.body.mobileno,
                birthDate: req.body.birthDate,
                address : req.body.address
            });

            const customerData = await customer.save();

            if (customerData) { 
                res.redirect('/customer/listCustomer');
            } else {
                res.render('addCustomer', { title: 'Registration', message: 'Your Registration has been failed..' });
            }

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Get Customer List Page----->>>
const getlistCustomerPage = async (req, res) => {
    try {
        //   const Data = await Customer.find()
        //     if (Data) {
        //         res.render("listCustomer", {
        //             title : 'All Customers',
        //             list : Data
        //         });
        //     }
        //     else {
        //         console.log('Error in retrieving customers list :' + err);
        //     }

        var search = '';
        if (req.query.search) {
            search = req.query.search
        }
        var page = 1;
        if (req.query.page) {
            page = req.query.page;
        }
        const limit = 2;
        const userData = await Customer.find({
            $or: [
                { customername: { $regex: '.*' + search + '.*', $options: 'i' } },
                { email: { $regex: '.*' + search + '.*', $options: 'i' } }

            ]
        })
            .limit(limit * 1)
            .skip((page - 1) * limit)
            .exec();

        const count = await Customer.find({
          
            $or: [
                { customername: { $regex: '.*' + search + '.*', $options: 'i' } },
                { email: { $regex: '.*' + search + '.*', $options: 'i' } }

            ]
        })
            .countDocuments();

        // const userData = await Customer.find();   
        res.render('listCustomer', {
             title : 'All Customers',
            list : userData,
            totalPages: Math.ceil(count / limit),
            currentPage: page,
            previous: page - 1,
            next: page + 1
        });

    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- Get User Edit Page ----->>>
const geteditCustomerPage = async (req, res) => {

    try {

        const id = req.params.id;

        const customerData = await Customer.findById({ _id: id });

        if (customerData) {

            res.render('editCustomer', { title: "Edit Customer", customer : customerData });

        } else {

            res.redirect('/error');
        }

    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Customer Details Update ----->>>
const postUpdateUser = async (req, res) => {

    try {

        const customerData = await Customer.findByIdAndUpdate({ _id: req.body.customer_id },
            {
                $set: {

                    customername: req.body.customername,
                    email: req.body.email,
                    mobileno: req.body.mobileno,
                    birthDate: req.body.birthDate,
                    address : req.body.address
                }
            });
            res.redirect('/customer/listCustomer')
    } catch (error) {

        console.log(error.message);

    }
};

//<<<----- For Delete Customer----->>>
const getDeleteCustomer = async (req, res) => {
    try {
      
       const deleteRecord =  await Customer.findByIdAndRemove({_id :req.params.id})
       
            if (deleteRecord) {
                const Data =  await Customer.find()
                res.render("listCustomer", {
                    title : 'All Customer',
                    list : Data
                })
            }
            else {
                console.log('Error in retrieving customers list :' + err);
            }
    } catch (error) {

        console.log(error.message);

    }
};


//<<<----- For Get LogOut Page----->>>
const getLogoutPage = async (req, res) => {
    try {
        req.session.destroy();
        res.redirect('/login');
    }
    catch (err) {
        console.log(err.message);
    }
}


module.exports = {
    getAddCustomerPage,
    postAddCustomerPage,
    getlistCustomerPage,
    geteditCustomerPage,
    postUpdateUser,
    getDeleteCustomer,
    getLogoutPage
    
}