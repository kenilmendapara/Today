const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();
const auth = require('../middlewares/auth');
const customerController = require('../controllers/customerController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/customer');

route.get("/addCustomer", auth.isLogin, customerController.getAddCustomerPage);

route.post("/addCustomer", customerController.postAddCustomerPage);

route.get("/listCustomer", auth.isLogin, customerController.getlistCustomerPage);

route.get("/editCustomer/:id", auth.isLogin, customerController.geteditCustomerPage);

route.post("/editCustomer", customerController.geteditCustomerPage);

route.get("/deleteCustomer/:id",  auth.isLogin, customerController.getDeleteCustomer);

route.get("/logout", auth.isLogin, customerController.getLogoutPage);

module.exports = route;
