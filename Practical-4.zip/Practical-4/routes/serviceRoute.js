const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const config = require('../config/config');
const auth = require('../middlewares/auth');
const stripe = require('stripe')(config.secretKey);
const route = express();

const serviceController = require('../controllers/serviceController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/service');

route.get("/addService", auth.isLogin, serviceController.getAddServicePage);

route.post("/addService", serviceController.postAddServicePage);

route.get("/listService", auth.isLogin, serviceController.getlistServicePage);

route.get("/editService/:id",  auth.isLogin, serviceController.geteditServicePage);

route.post("/editService", serviceController.postUpdateService);

route.get("/deleteService/:id",  auth.isLogin, serviceController.getDeleteService);

route.get('/payment/:id',  auth.isLogin, serviceController.getPayment);

route.post('/create-checkout-session', serviceController.postPayments);

route.get('/success',  auth.isLogin, serviceController.getPaymentSuccess);

route.get('/cancel',  auth.isLogin, serviceController.getPaymentCancel);

route.get("/logout", auth.isLogin, serviceController.getLogoutPage);


module.exports = route;