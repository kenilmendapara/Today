const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();
const cookieParser = require('cookie-parser');
const userController = require('../controllers/userController');
const auth = require('../middlewares/auth');
const config = require('../config/config');
const session = require('express-session');

route.use(session({
    secret: config.sessionSecret,
    resave: false,
    saveUninitialized: false,
    expires: new Date(Date.now() + 300000 )
}));

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));
route.use(cookieParser());

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/user');

route.get("/", auth.isLogout, userController.getLoginPage);
route.get("/login", auth.isLogout, userController.getLoginPage);

route.post("/login", userController.postVerifyLogin);

route.get("/register", auth.isLogout, userController.getRegisterPage);

route.post('/register', userController.postInsertUser);

route.get("/error", auth.isLogin, userController.getError404Page);

route.get("/userDashboard", auth.isLogin, userController.getUserDashboard);

route.get("/logout", auth.isLogin, userController.getLogoutPage);


module.exports = route;