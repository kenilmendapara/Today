const express = require('express');
const ejs = require('ejs');
const path = require('path');
const bodyParser = require('body-parser');
const route = express();
const auth = require('../middlewares/auth');
const adminController = require('../controllers/adminController');

const static_path = path.join(__dirname, "../public/");
route.use(express.static(static_path));

route.use(bodyParser.json());
route.use(bodyParser.urlencoded({ extended: true }));

route.set('view engine', 'ejs');
route.set('views', './views/admin');

route.get("/adminDashboard", auth.isLogin, adminController.getAdminDashboard);

route.get("/addUser", auth.isLogin, adminController.getUserAddPage);

route.post("/addUser", adminController.postUserAddPage);

route.get("/listUser",  auth.isLogin, adminController.getlistUserPage);

route.get("/editUser/:id",  auth.isLogin, adminController.geteditUserPage);

route.post("/editUser", adminController.postUpdateUser);

route.get("/deleteUser/:id",  auth.isLogin, adminController.getDeleteUser);

route.get("/logout", auth.isLogin, adminController.getLogoutPage);



module.exports = route;