const sessionSecret = "mysitesessionsecret";
const emailUser = 'kenilpatel1552@gmail.com';
const emailPassword = 'ysobvfmfwmkguaos'; 
const myString = 'fdgdgfdifhfdivhfdvfdhfdvhfdv';
const publisableKey = "pk_test_51MgMB4SCqeHF5bbP3AZFdV0jy9eCbIGzXCmJFjHv0m1NiWiwmw1sR5YBwcLtKo2UPS3JiIMFQlomPHjvzYY64k4R00XLkbXKLz";
const secretKey ="sk_test_51MgMB4SCqeHF5bbPsG1KsUWwBh38vLGuiKN0S6hHAco3JiNkRlisAnVdqgvBrwkMCqNqbbR9ynFHofgsIQsgVFMx00TCwTQWeD";
const port = process.env.PORT || 3232;
module.exports = {
    sessionSecret,
    emailUser,
    emailPassword,
    myString,
    publisableKey,
    secretKey,
    port
}