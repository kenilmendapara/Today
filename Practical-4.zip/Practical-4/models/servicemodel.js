const mongoose = require('mongoose');

var serviceSchema = new mongoose.Schema({

    customername :{
        type : String
         // unique: true,
        // require: true,
        // trim : true,
        // minlength : [2, "username is has minimum 2 letter"],
        // maxlength : [20, "username is has maximum 20 letter"]
    },
    vehicleNumber: {
        type: String
    },
    email: {
        type: String
          // unique: true,
        // require: true,
        // trim : true,
        // validate(value){
        //     if(!validator.isEmail(value)){
        //         throw new Error("Email is Invalid.")
        //     }
        // }

    },
    pickUpDate: {
        type: Date
    },
    dropDate: {
        type: Date
    },
    servicePrice: {
        type: Number
    },
    payableAmount: {
        type : Number
    }

});

module.exports = mongoose.model('Service', serviceSchema);