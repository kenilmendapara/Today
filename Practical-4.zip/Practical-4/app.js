const express = require('express');
const app = express();
const { port } = require("./config/config")

//<<<----- For Database Connection ----->>>
const mongoose = require('mongoose');
mongoose.connect("mongodb://0.0.0.0:27017/Practical-4", {
    useNewUrlParser: true
});

//<<<----- All User Routes Running on this----->>>
const userRoute = require('./routes/userRoute')
app.use('/', userRoute);

//<<<----- All Service Routes Running on this----->>>
const serviceRoute = require('./routes/serviceRoute')
app.use('/service', serviceRoute);

//<<<----- All Customer Routes Running on this----->>>
const customerRoute = require('./routes/customerRoute')
app.use('/customer', customerRoute);

//<<<----- All Admin Routes Running on this----->>>
const adminRoute = require('./routes/adminRoute')
app.use('/admin', adminRoute);

//<<<----- For Server Listening----->>>
app.listen(port, () => {
    console.log(`server is listening on http://localhost:${port}/login`);
});